<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editsports?id=').$before1; ?>">Sports Details</a></li>
<li><a href="<?php echo site_url('site/viewsportscategory?id=').$before->id; ?>">Sports Category</a></li>
</ul>
</div>
</section>