<?php
echo getconfig("projectname");
?>