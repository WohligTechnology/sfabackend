<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editschool?id=').$before2; ?>">School Details</a></li>
<li><a href="<?php echo site_url('site/viewstudent?id=').$before1; ?>">Students Details</a></li>
</ul>
</div>
</section>