<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/viewschoolregistrationsports?id=').$before1; ?>">Registered Sports</a></li>
</ul>
</div>
</section>