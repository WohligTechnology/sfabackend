<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editschool?id=').$before2; ?>">School Details</a></li>
<li><a href="<?php echo site_url('site/editstudent?id=').$before1; ?>">Students Details</a></li>
<li><a href="<?php echo site_url('site/viewteam?id='.$before3.'&schoolid=').$before4; ?>">Team Details</a></li>
</ul>
</div>
</section>